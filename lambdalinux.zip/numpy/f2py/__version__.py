from numpy.version import version
